To install dependencies run:

npm init -y
npm install express socket.io


