const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

let players = [];
let board = Array(9).fill(null); // Tablero inicial
let currentPlayer = 1; // El jugador 1 siempre comienza
let gameActive = true;

// Middleware para servir archivos estáticos
app.use(express.static('public'));

// Ruta principal
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

// Lógica de conexión con Socket.IO
io.on('connection', (socket) => {
    console.log('Un jugador se ha conectado:', socket.id);

    if (players.length < 2) {
        players.push(socket.id);
        const playerNumber = players.length;
        socket.emit('player', playerNumber);
        console.log(`Jugador ${playerNumber} asignado: ${socket.id}`);
    } else {
        socket.emit('spectator');
        console.log('Espectador conectado:', socket.id);
    }

    // Escuchar movimientos
    socket.on('move', (data) => {
        if (!gameActive) {
            socket.emit('message', 'El juego ha terminado.');
            return;
        }

        const { index, player } = data;

        // Validar turno y movimiento
        if (player !== currentPlayer || board[index] !== null) {
            socket.emit('message', 'Movimiento inválido.');
            return;
        }

        // Realizar el movimiento
        const symbol = player === 1 ? 'X' : 'O';
        board[index] = symbol;

        // Emitir el movimiento a todos
        io.emit('move', { index, symbol });

        // Verificar si el juego ha terminado
        const winner = checkWinner();
        if (winner) {
            gameActive = false;
            io.emit('message', `Jugador ${player} ha ganado.`);
        } else if (board.every((cell) => cell !== null)) {
            gameActive = false;
            io.emit('message', 'Empate.');
        } else {
            // Cambiar turno
            currentPlayer = currentPlayer === 1 ? 2 : 1;
            io.emit('turn', currentPlayer);
        }
    });

    // Reiniciar el juego
    socket.on('reset', () => {
        if (players.includes(socket.id)) {
            resetGame();
            io.emit('reset', { board, currentPlayer });
        }
    });

    // Manejo de desconexión
    socket.on('disconnect', () => {
        console.log('Un jugador se ha desconectado:', socket.id);
        players = players.filter((player) => player !== socket.id);
        resetGame();
    });
});

// Función para verificar si alguien ha ganado
function checkWinner() {
    const winningCombinations = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], // Filas
        [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columnas
        [0, 4, 8], [2, 4, 6]            // Diagonales
    ];

    for (const combination of winningCombinations) {
        const [a, b, c] = combination;
        if (board[a] && board[a] === board[b] && board[a] === board[c]) {
            return true;
        }
    }
    return false;
}

// Función para reiniciar el juego
function resetGame() {
    board = Array(9).fill(null);
    currentPlayer = 1;
    gameActive = true;
}

// Iniciar el servidor
const PORT = 3000;
server.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
