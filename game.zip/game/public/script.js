const socket = io();
let player = null;
let currentPlayer = 1;

// Seleccionar elementos del DOM
const cells = document.querySelectorAll('.cell');
const statusDiv = document.getElementById('status');

// Escuchar la asignación de jugador
socket.on('player', (assignedPlayer) => {
    player = assignedPlayer;
    statusDiv.textContent = `Eres el jugador ${player} (${player === 1 ? 'X' : 'O'})`;
});

// Escuchar el turno actual
socket.on('turn', (current) => {
    currentPlayer = current;
    if (player === currentPlayer) {
        statusDiv.textContent = 'Tu turno';
    } else {
        statusDiv.textContent = 'Esperando al otro jugador...';
    }
});

// Escuchar movimientos
socket.on('move', (data) => {
    const { index, symbol } = data;
    cells[index].textContent = symbol;
    cells[index].classList.add('taken');
});

// Escuchar mensajes del servidor
socket.on('message', (message) => {
    statusDiv.textContent = message;
});

// Escuchar reinicio
socket.on('reset', (data) => {
    const { board, currentPlayer } = data;
    cells.forEach((cell, index) => {
        cell.textContent = '';
        cell.classList.remove('taken');
    });
    statusDiv.textContent = 'Juego reiniciado. Es turno del jugador 1.';
});

// Manejar clics en las celdas
cells.forEach((cell, index) => {
    cell.addEventListener('click', () => {
        if (player !== currentPlayer || cell.classList.contains('taken')) return;

        // Enviar el movimiento al servidor
        socket.emit('move', { index, player });
    });
});
