<?php include('db.php'); ?>

<?php
$id = $_GET['id'];
$result = $conn->query("SELECT * FROM Animales WHERE id_animal = $id");
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Animal</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Editar Información del Animal</h1>
    <form action="" method="POST">
        <label>Nombre:</label>
        <input type="text" name="nombre" value="<?= $row['nombre'] ?>" required>
        <label>Especie:</label>
        <input type="text" name="especie" value="<?= $row['especie'] ?>" required>
        <label>Edad:</label>
        <input type="number" name="edad" value="<?= $row['edad'] ?>">
        <label>Estado:</label>
        <input type="text" name="estado" value="<?= $row['estado'] ?>" required>
        <button type="submit" name="submit">Actualizar</button>
    </form>

    <?php
    if (isset($_POST['submit'])) {
        $nombre = $_POST['nombre'];
        $especie = $_POST['especie'];
        $edad = $_POST['edad'];
        $estado = $_POST['estado'];

        $sql = "UPDATE Animales SET 
                nombre = '$nombre', 
                especie = '$especie', 
                edad = $edad, 
                estado = '$estado' 
                WHERE id_animal = $id";
        if ($conn->query($sql)) {
            echo "<p style='text-align: center; color: green;'>Animal actualizado correctamente.</p>";
        } else {
            echo "<p style='text-align: center; color: red;'>Error: " . $conn->error . "</p>";
        }
    }
    ?>
    <div style="text-align: center; margin-top: 20px;">
        <a href="index.php"><button>Volver al Inicio</button></a>
    </div>
</body>
</html>
