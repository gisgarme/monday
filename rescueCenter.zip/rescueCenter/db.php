<?php
$host = 'localhost'; // Cambiar según la configuración del servidor
$user = 'root';
$password = '';
$database = 'CentroRescate';

$conn = new mysqli($host, $user, $password, $database);

// Comprobar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
