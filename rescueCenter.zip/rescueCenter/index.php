<?php include('db.php'); ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Centro de Rescate de Animales</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Centro de Rescate de Animales</h1>
    <div style="text-align: center; margin: 20px;">
        <a href="add.php">
            <button>Añadir Nuevo Animal</button>
        </a>
    </div>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Especie</th>
                <th>Edad</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $result = $conn->query("SELECT * FROM Animales");
            while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id_animal'] ?></td>
                    <td><?= $row['nombre'] ?></td>
                    <td><?= $row['especie'] ?></td>
                    <td><?= $row['edad'] ?></td>
                    <td><?= $row['estado'] ?></td>
                    <td>
                        <a href="edit.php?id=<?= $row['id_animal'] ?>">Editar</a>
                        <a href="delete.php?id=<?= $row['id_animal'] ?>" onclick="return confirm('¿Estás seguro?')">Eliminar</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>
