How to run the Centro de Rescate project

1. Download the  zip file

2. Extract the file and copy rescueCenter folder

3. Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name rescueCenter

6. Import script.sql file(given inside the zip package in SQL file folder)

7. Run the script http://localhost/rescueCenter/script.sql (frontend)

8. To access the project enter http://localhost/rescueCenter/index.php

Credential for admin:

Username: root
Password: 

