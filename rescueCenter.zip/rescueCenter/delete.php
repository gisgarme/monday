<?php include('db.php'); ?>

<?php
$id = $_GET['id'];
$sql = "DELETE FROM Animales WHERE id_animal = $id";
if ($conn->query($sql)) {
    header("Location: index.php");
    exit();
} else {
    echo "<p style='text-align: center; color: red;'>Error: " . $conn->error . "</p>";
}
?>
