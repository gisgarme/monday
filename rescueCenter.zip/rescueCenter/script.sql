-- Crear la base de datos
CREATE DATABASE IF NOT EXISTS CentroRescate;
USE CentroRescate;

-- Tabla para almacenar la información de los animales
CREATE TABLE Animales (
    id_animal INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    especie VARCHAR(50) NOT NULL,
    raza VARCHAR(50),
    edad INT,
    fecha_rescate DATE NOT NULL,
    estado VARCHAR(100) NOT NULL DEFAULT 'En refugio',
    observaciones TEXT
);

-- Tabla para los rescatistas
CREATE TABLE Rescatistas (
    id_rescatista INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    telefono VARCHAR(15),
    email VARCHAR(100),
    direccion TEXT
);

-- Tabla para los detalles del rescate
CREATE TABLE Rescates (
    id_rescate INT AUTO_INCREMENT PRIMARY KEY,
    id_animal INT NOT NULL,
    id_rescatista INT,
    fecha_rescate DATE NOT NULL,
    lugar_rescate VARCHAR(255),
    observaciones TEXT,
    FOREIGN KEY (id_animal) REFERENCES Animales(id_animal) ON DELETE CASCADE,
    FOREIGN KEY (id_rescatista) REFERENCES Rescatistas(id_rescatista) ON DELETE SET NULL
);

-- Tabla para gestionar adopciones
CREATE TABLE Adopciones (
    id_adopcion INT AUTO_INCREMENT PRIMARY KEY,
    id_animal INT NOT NULL,
    nombre_adoptante VARCHAR(100) NOT NULL,
    telefono_adoptante VARCHAR(15),
    email_adoptante VARCHAR(100),
    direccion_adoptante TEXT,
    fecha_adopcion DATE NOT NULL,
    observaciones TEXT,
    FOREIGN KEY (id_animal) REFERENCES Animales(id_animal) ON DELETE CASCADE
);

-- Tabla para gestionar la atención médica de los animales
CREATE TABLE AtencionMedica (
    id_atencion INT AUTO_INCREMENT PRIMARY KEY,
    id_animal INT NOT NULL,
    fecha_atencion DATE NOT NULL,
    descripcion TEXT NOT NULL,
    veterinario VARCHAR(100),
    costo DECIMAL(10, 2),
    FOREIGN KEY (id_animal) REFERENCES Animales(id_animal) ON DELETE CASCADE
);

-- Insertar datos de ejemplo
INSERT INTO Animales (nombre, especie, raza, edad, fecha_rescate, estado, observaciones)
VALUES
('Luna', 'Perro', 'Labrador', 3, '2024-11-01', 'En refugio', 'Encontrada en mal estado'),
('Mimi', 'Gato', 'Siamés', 2, '2024-11-15', 'En refugio', 'Muy tímida'),
('Rocky', 'Perro', 'Bulldog', 5, '2024-11-20', 'En refugio', 'Tiene problemas respiratorios');

INSERT INTO Rescatistas (nombre, telefono, email, direccion)
VALUES
('Juan Pérez', '600123456', 'juan.perez@example.com', 'Calle Falsa 123, Ciudad'),
('María López', '610987654', 'maria.lopez@example.com', 'Av. Siempreviva 456, Ciudad');

INSERT INTO Rescates (id_animal, id_rescatista, fecha_rescate, lugar_rescate, observaciones)
VALUES
(1, 1, '2024-11-01', 'Parque Central', 'Animal herido en la pata trasera'),
(2, 2, '2024-11-15', 'Barrio Los Álamos', 'Gato abandonado en una caja'),
(3, 1, '2024-11-20', 'Autopista Sur', 'Perro encontrado deambulando');

-- Confirmar estructura y datos
SHOW TABLES;
