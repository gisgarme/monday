<?php include('db.php'); ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Añadir Nuevo Animal</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Añadir Nuevo Animal</h1>
    <form action="" method="POST">
        <label>Nombre:</label>
        <input type="text" name="nombre" required>
        <label>Especie:</label>
        <input type="text" name="especie" required>
        <label>Edad:</label>
        <input type="number" name="edad">
        <label>Estado:</label>
        <input type="text" name="estado" value="En refugio" required>
        <button type="submit" name="submit">Guardar</button>
    </form>

    <?php
    if (isset($_POST['submit'])) {
        $nombre = $_POST['nombre'];
        $especie = $_POST['especie'];
        $edad = $_POST['edad'];
        $estado = $_POST['estado'];

        $sql = "INSERT INTO Animales (nombre, especie, edad, estado, fecha_rescate) 
                VALUES ('$nombre', '$especie', '$edad', '$estado', CURDATE())";
        if ($conn->query($sql)) {
            echo "<p style='text-align: center; color: green;'>Animal añadido correctamente.</p>";
        } else {
            echo "<p style='text-align: center; color: red;'>Error: " . $conn->error . "</p>";
        }
    }
    ?>
    <div style="text-align: center; margin-top: 20px;">
        <a href="index.php"><button>Volver al Inicio</button></a>
    </div>
</body>
</html>
